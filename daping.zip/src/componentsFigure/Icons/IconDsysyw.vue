<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <path fill="currentColor"
            d="M19.714 5.23 24 2.693 22.286 1 18 3.538V7.77h1.714V5.231ZM18 8.616v8.462H0v3.384h1.714C1.728 21.81 2.934 23 4.286 23s2.558-1.19 2.571-2.539h9.429C16.299 21.81 17.506 23 18.857 23c1.352 0 2.558-1.19 2.572-2.539h1.714V12l-2.572-3.385h-2.57Z"
            data-follow-fill="currentColor" />
        <path fill="currentColor"
            d="M15.268 3.606H2.526v11.992h12.742V3.606Zm-1.5 10.493H4.026V5.105h3.748v2.998h2.248V5.105h3.748v8.994Z"
            data-follow-fill="currentColor" />
    </svg>
</template>