<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 27 33">
        <g filter="url(#a)">
            <path fill="#5CDAF5" d="m10.5 10 6.5 6.5-6.5 6.5V10Z" data-follow-fill="#5CDAF5" />
        </g>
        <path fill="#5CDAF5" d="m10.5 10 6.5 6.5-6.5 6.5V10Z" data-follow-fill="#5CDAF5" />
        <defs>
            <filter color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" height="33" width="26.5" y="0"
                x=".5" id="a">
                <feFlood result="BackgroundImageFix" flood-opacity="0" />
                <feBlend result="shape" in2="BackgroundImageFix" in="SourceGraphic" />
                <feGaussianBlur result="effect1_foregroundBlur_811_208" stdDeviation="5" />
            </filter>
        </defs>
    </svg>
</template>