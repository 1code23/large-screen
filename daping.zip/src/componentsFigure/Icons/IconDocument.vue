<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <path fill="currentColor"
            d="M16.351 6a1 1 0 0 1 0-2h2.922C20.217 4 21 4.749 21 5.696v2.01a1 1 0 1 1-2 0V6h-2.649ZM19 20v-8.362a1 1 0 0 1 2 0v8.666c0 .947-.783 1.696-1.727 1.696H4.727C3.783 22 3 21.251 3 20.304V5.696C3 4.749 3.783 4 4.727 4h2.924a1 1 0 1 1 0 2H5v14h14ZM8.636 12.69a1 1 0 1 1 0-2h7.5a1 1 0 0 1 0 2h-7.5ZM10 4a1 1 0 1 0 0 2h4a1 1 0 0 0 0-2h-4Zm0-2h4a3 3 0 1 1 0 6h-4a3 3 0 1 1 0-6ZM8.636 16.326a1 1 0 0 1 0-2h7.5a1 1 0 0 1 0 2h-7.5Z"
            data-follow-fill="currentColor" />
    </svg>
</template>