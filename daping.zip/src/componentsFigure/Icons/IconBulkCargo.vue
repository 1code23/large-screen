<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 52 52">
        <path fill="currentColor" d="M7 15.018 26.32 4 46 15.018v22.035L26.464 48V25.894L7 15.018Z"
            data-follow-fill="currentColor" />
        <path fill="currentColor" d="M7 19v7.247l9.484 5.187v10.942L23 46V27.953L7 19Z"
            data-follow-fill="currentColor" />
        <path fill="currentColor" d="M7 30v7.282L13 41v-7.36L7 30Z" data-follow-fill="currentColor" />
    </svg>
</template>