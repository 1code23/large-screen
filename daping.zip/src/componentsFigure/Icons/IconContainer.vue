<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 52 29">
        <g clip-path="url(#a)">
            <path fill="currentColor"
                d="M0 3.282 12.285 0l39.017 6.704V29l-39.017-1.258L0 29V3.282ZM13.812 3v22h3.946V3.513L13.812 3ZM3.946 5.001V27l3.946-.416V3.977L3.946 5.001Zm17.76 0v20h3.947V5.465l-3.947-.464ZM29.598 7v18h3.946V7.417L29.598 7Zm7.892 2v16h3.949V9.373l-3.949-.371Zm7.895 2.002V25h3.946V11.326L45.385 11Z" />
        </g>
        <defs>
            <clipPath id="a">
                <path fill="#fff" d="M0 0h52v29H0z" />
            </clipPath>
        </defs>
    </svg>
</template>