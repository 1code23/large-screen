<template>
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <path fill="url(#a5)"
            d="m11.897 0 11.898 4.103-11.898 4.102L0 4.103 11.897 0ZM0 7.59l10.461 3.487V24L0 20.513V7.59Zm24 0v12.923l-10.461 3.282V10.872L24 7.59Z" />
        <defs>
            <linearGradient gradientUnits="userSpaceOnUse" y2="24" x2="12" y1="-5.538" x1="12" id="a5">
                <stop stop-color="#044659" />
                <stop stop-color="#8AFE93" offset=".429" />
                <stop stop-opacity="0" stop-color="#044659" offset="1" />
            </linearGradient>
        </defs>
    </svg>
</template>