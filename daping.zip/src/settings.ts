export default {
  title: "陕果产业数据中台分析",
  version: "v0.0.2",
};
